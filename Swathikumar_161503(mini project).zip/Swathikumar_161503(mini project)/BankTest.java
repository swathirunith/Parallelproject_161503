package com.cg.bank.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.bank.exception.AccountException;
import com.cg.bank.exception.AmountException;
import com.cg.bank.exception.NameException;
import com.cg.bank.exception.PhoneNumberException;
import com.cg.bank.service.AccountServiceImpl;

public class BankTest {
	
	@Test
	public void ValidateNameTrue() throws NameException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(true, as.validateName("Swathi"));
	}
	@Test 
	public void ValidateName() throws NameException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(false, as.validateName("Kumar"));
		assertEquals(false, as.validateName("Coral"));
		assertEquals(false, as.validateName("Monisha@#"));
		assertEquals(false, as.validateName("987456"));
	}
	
	@Test
	public void ValidatePhonNumberTrue() throws PhoneNoException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(true, as.validatePhoneNo("9940745281"));
	}
	
	@Test
	public void ValidatePhoneNumber() throws PhoneNumberException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(false, as.validatePhoneNumber("96575"));
		assertEquals(false, as.validatePhoneNumber("9636758741"));
		assertEquals(false, as.validatePhoneNumber("78676"));
		assertEquals(false, as.validatePhoneNumber("test"));
		assertEquals(false, as.validatePhoneNumber("@#*%"));
	}
	
	@Test
	public void ValidateAmountTrue() throws AmountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(true, bs.validateAmount("100"));
	}
	
	@Test 
	public void ValidateAmount() throws AmountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(false, bs.validateAmount("0"));
		assertEquals(false, bs.validateAmount("-100"));
	}
	
	@Test
	public void ValidateAccountTrue() throws AccountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(true, bs.validateAmount("50000"));
		
	}
	@Test 
	public void ValidateAccount() throws AmountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(false, bs.validateAmount("0"));
		assertEquals(false, bs.validateAmount("-70000"));
	}
	

}
